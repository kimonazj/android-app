package com.example.w3_p2;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    SeekBar CelsiusBar;
    SeekBar FahrenheitBar;
    TextView CelsiusTag;
    TextView FahrenheitTag;
    TextView CelsiusNum;
    TextView FahrenheitNum;
    TextView message;

    private void updateMessage(){
        if (CelsiusBar.getProgress() > 12.0 && CelsiusBar.getProgress() < 40.0){
            message.setText(R.string.it_is_not_cold);
        }
        else if(CelsiusBar.getProgress()>40.0){
            message.setText(R.string.it_is_too_hot);
        }
        else{
            message.setText(R.string.it_is_so_cold);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CelsiusBar = (SeekBar)findViewById(R.id.CelsiusBar);
        FahrenheitBar = (SeekBar)findViewById(R.id.FahrenheitBar);

        CelsiusTag = (TextView)findViewById(R.id.CelsiusTag);
        FahrenheitTag = (TextView)findViewById(R.id.FahrenheitTag);

        CelsiusNum = (TextView)findViewById(R.id.CelsiusNum);
        FahrenheitNum = (TextView)findViewById(R.id.FahrenheitNum);

        message = (TextView)findViewById(R.id.message);

        CelsiusBar.setProgress(0);
        FahrenheitBar.setProgress(3200);
        CelsiusNum.setText("0.00");
        FahrenheitNum.setText("32.00");
        updateMessage();


        CelsiusBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            double CelsiusBarValue = 0;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                CelsiusBarValue = progress/100.00;
                CelsiusNum.setText(String.format(Locale.getDefault(), "%.2f", CelsiusBarValue*100));

                FahrenheitNum.setText(String.format(Locale.getDefault(), "%.2f", (CelsiusBarValue*100*9/5+32)));
                FahrenheitBar.setProgress((int)(CelsiusBarValue*9/5+32)*100);
                updateMessage();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar){
            }
        });

        FahrenheitBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            double FahrenheitBarValue = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                FahrenheitBarValue = progress/100.00;
                FahrenheitNum.setText(String.format(Locale.getDefault(), "%.2f", FahrenheitBarValue));

                CelsiusNum.setText(String.format(Locale.getDefault(), "%.2f",(FahrenheitBarValue-32)*5/9));
                CelsiusBar.setProgress((int)(FahrenheitBarValue-32)*(5/9)*100);
                updateMessage();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}
