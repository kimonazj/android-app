package com.example.c3_p33;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class SecondFragment extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_second);

        EditText inputShift = findViewById(R.id.inputShift);
        Button shiftBtn = findViewById(R.id.DefineShiftBtn);

        shiftBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int shiftNum = Integer.parseInt(inputShift.getText().toString());
                if(shiftNum >= 1 && shiftNum <= 25){
                    MainActivity.cipherShift.setShift(shiftNum);
                    finish();
                }
                else{
                    Toast.makeText(getApplicationContext(),"Invalid input!",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}