package com.example.c3_p33;

import android.os.Bundle;

import android.content.Intent;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static CipherShift cipherShift;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button changebtn = findViewById(R.id.changebtn);
        Button definebtn = findViewById(R.id.definebtn);
        EditText input = findViewById(R.id.input);
        TextView output = findViewById(R.id.output);
        cipherShift = new CipherShift();

        changebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cipherShift.setWord(input.getText().toString());
                String outputString = cipherShift.calculate();
                output.setText(outputString);
            }
        });

        definebtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // this will go to activity 2
                Intent myIntent = new Intent(MainActivity.this, SecondFragment.class);
                startActivity(myIntent);
            }
        }));

    }

}