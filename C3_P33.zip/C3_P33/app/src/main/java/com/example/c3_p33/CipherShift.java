package com.example.c3_p33;

public class CipherShift {

    String word = "";
    int shift = 0;

    public CipherShift(){

    }

    public int getShift(){
        return this.shift;
    }

    public String getWord(){
        return this.word;
    }

    public void setWord(String input){
        this.word = input;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }

    public String calculate(){
        StringBuffer result = new StringBuffer();
        for (int i = 0; i < word.length(); i++){
            char ch = (char) ((((int)word.charAt(i)+ shift - 97 ) % 26 ) + 97);
            result.append(ch);
        }
        return result.toString();
    }
}
