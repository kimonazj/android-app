package com.example.exam_1b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public static final int MAXROUND = 5;

    private Button b1;
    private Button b2;
    private Button b3;
    private Button b4;
    private Button b5;
    private Button b6;
    private Button b7;

    private Button start;
    private Button submit;
    private TextView score;

    private List<Button> btnlist;

    private int round;
    private int userScore;
    private List<String> strArray;

    //start one game function
    private void startOneGame(){
        //initiate all the buttons with random words
        for(int i = 0; i<7 ; i++){
            Random rnd = new Random();
            char c = (char)('A'+ rnd.nextInt(26));
            String s = String.valueOf(c);
            btnlist.get(i).setText(s);
            btnlist.get(i).setEnabled(true);
        }
        //the user score is 0 for each round
        userScore = 0;
    }

    //when a button is clicked (early binding)
    public void keyClicked(View v){
        // get the letter and set the button disabled
        String letter = ((Button)v).getText().toString();
        strArray.add(letter);
        v.setEnabled(false);
        //add the score
        userScore += 2;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initiate buttons and a button list
        //the button list is used for adding text to each button latter
        btnlist = new ArrayList<Button>();

        b1 = (Button)findViewById(R.id.b1); btnlist.add(b1);
        b2 = (Button)findViewById(R.id.b2); btnlist.add(b2);
        b3 = (Button)findViewById(R.id.b3); btnlist.add(b3);
        b4 = (Button)findViewById(R.id.b4); btnlist.add(b4);
        b5 = (Button)findViewById(R.id.b5); btnlist.add(b5);
        b6 = (Button)findViewById(R.id.b6); btnlist.add(b6);
        b7 = (Button)findViewById(R.id.b7); btnlist.add(b7);

        //set up start and submit buttons
        start = (Button)findViewById(R.id.start);
        submit = (Button)findViewById(R.id.submit);

        //find the score display textview
        score = (TextView)findViewById(R.id.score);
        strArray = new ArrayList<String>();

        //set round and userScore to 0 when start the program
        round = 0;
        userScore = 0;

        //since we haven't start the game, it should not be able to submit
        submit.setEnabled(false);

        //when the start button is clicked
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //set the score to 0 and start the game
                score.setText("0");
                startOneGame();
                //the game is started, we should count it once
                round+=1;
                //disable the start button once it's clicked and enable the submit button
                start.setEnabled(false);
                submit.setEnabled(true);
            }
        });

        //when the submit button is clicked
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // if it's not MAXROUND, which is 5, start one more round
                if(round < MAXROUND){
                    score.setText(String.valueOf(userScore));
                    startOneGame();
                    round += 1;
                }
                else{
                    //when the round reaches its max number, enable start button and make a toast
                    Toast.makeText(MainActivity.this,"You can start a new game", Toast.LENGTH_SHORT).show();
                    score.setText(String.valueOf(userScore));
                    start.setEnabled(true);
                    round = 0;
                    //since the game is not started, we should disable the submit button
                    submit.setEnabled(false);
                }
            }
        });


    }
}