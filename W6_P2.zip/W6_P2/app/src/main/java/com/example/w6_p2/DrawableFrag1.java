package com.example.w6_p2;

import android.app.Fragment;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import java.lang.reflect.Field;
import java.util.ArrayList;

public class DrawableFrag1 extends Fragment{

    private Button btnLeft;
    private Button btnRight;

    private int imgIndex;
    private int resourceSize;

    ButtonListener main_class;

    public DrawableFrag1() {
        // Required empty public constructor
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        main_class = (ButtonListener) context;
    }

    // Detach the DrawableListener reference to save memory
    @Override
    public void onDetach() {
        super.onDetach();
        main_class = null;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_drawable, container, false);  //comment this out, it would return the default view, without our setup/amendments.
        View v = inflater.inflate(R.layout.fragment_1, container, false);   //MUST HAPPEN FIRST, otherwise components don't exist.

        btnRight = (Button) v.findViewById(R.id.btnRight);
        btnLeft = (Button) v.findViewById(R.id.btnLeft);

        resourceSize = 0;
        imgIndex = 0;

        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (imgIndex == 0)
                    imgIndex = resourceSize - 1;
                else
                    imgIndex--;
                main_class.setImgIndex(imgIndex);
            }
        });

        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgIndex = (imgIndex + 1) % resourceSize;
                main_class.setImgIndex(imgIndex);
            }
        });

        return v;
    }

    public interface ButtonListener {
        void setImgIndex(int index);
    }

    public void setResourceSize(int size) {
        resourceSize = size;
    }
}