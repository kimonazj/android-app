package com.example.w6_p2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;

public class MainActivity extends Activity implements DrawableFrag1.ButtonListener, DrawableFrag2.DrawableListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    @Override
    public void setImgIndex(int index) {
        DrawableFrag2 drawableFragment = (DrawableFrag2) getFragmentManager().findFragmentById(R.id.fragment2);
        drawableFragment.setImgIndex(index);
        drawableFragment.changePicture();
    }

    @Override
    public void passResourceSize(int size) {
        DrawableFrag1 buttonFragment = (DrawableFrag1) getFragmentManager().findFragmentById(R.id.bottomFragment);
        buttonFragment.setResourceSize(size);
    }
}