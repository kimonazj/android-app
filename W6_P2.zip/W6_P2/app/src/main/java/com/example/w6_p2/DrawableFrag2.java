package com.example.w6_p2;

import android.app.Fragment;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;

import java.lang.reflect.Field;
import java.util.ArrayList;

public class DrawableFrag2 extends Fragment {

    ArrayList<Drawable> drawables;  //keeping track of our drawables
    private int currDrawableIndex;  //keeping track of which drawable is currently displayed.

    //Boiler Plate Stuff.
    private ImageView imgRateMe;
    float[] ratings;
    private RatingBar ratingBar;

    private DrawableListener main_class;

    public DrawableFrag2(){
        //required
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment2, container, false);
        imgRateMe = (ImageView) v.findViewById(R.id.imgRateMe);
        ratingBar = (RatingBar) v.findViewById(R.id.ratingBar);


        currDrawableIndex = 0;  //ArrayList Index of Current Drawable.
        getDrawables();         //Retrieves the drawables we want, ie, prefixed with "animal_"
        ratings = new float[drawables.size()];
        passResourceSize();
        imgRateMe.setImageDrawable(null);  //Clearing out the default image from design time.
        changePicture();        //Sets the ImageView to the first drawable in the list.


        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                ratings[currDrawableIndex] = v;
            }
        });

        return v;   //returns the view, with our must happen last, Why? A: ____________
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        main_class = (DrawableListener) context;
    }
    // Detach the DrawableListener reference to save memory
    @Override
    public void onDetach() {
        super.onDetach();
        main_class = null;
    }

    public interface DrawableListener {
        public void passResourceSize(int size);
    }

    //Routine to change the picture in the image view dynamically.
    public void changePicture() {
        imgRateMe.setImageDrawable(drawables.get(currDrawableIndex));  //note, this is the preferred way of changing images, don't worry about parent viewgroup size changes.
        ratingBar.setRating(ratings[currDrawableIndex]);
    }

    //Quick and Dirty way to get drawable resources, we prefix with "animal_" to filter out just the ones we want to display.
//REF: http://stackoverflow.com/questions/31921927/how-to-get-all-drawable-resources
    public void getDrawables() {
        Field[] drawablesFields = com.example.w6_p2.R.drawable.class.getFields();  //getting array of ALL drawables.
        drawables = new ArrayList<>();  //we prefer an ArrayList, to store the drawables we are interested in.  Why ArrayList and not an Array here? A: _________

        String fieldName;
        for (Field field : drawablesFields) {   //1. Looping over the Array of All Drawables...
            try {
                fieldName = field.getName();    //2. Identifying the Drawables Name, eg, "animal_bewildered_monkey"
                Log.i("LOG_TAG", "com.your.project.R.drawable." + fieldName);
                if (fieldName.startsWith("animals_"))  //3. Adding drawable resources that have our prefix, specifically "animal_".
                    drawables.add(getResources().getDrawable(field.getInt(null)));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void setImgIndex(int index) {
        currDrawableIndex = index;
    }

    public void passResourceSize() {
        main_class.passResourceSize(drawables.size());
    }
}
