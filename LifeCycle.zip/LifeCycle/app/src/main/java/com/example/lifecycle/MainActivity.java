package com.example.lifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static String LC = "LifeCycle";
    private Button btnSayHello;
    private EditText editTxtHello;
    private TextView viewTxtHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(LC, "This triggered onCreate");

        btnSayHello = (Button) findViewById(R.id.btnSayHello);
        editTxtHello = (EditText) findViewById(R.id.editTxtHello);
        viewTxtHello = (TextView) findViewById(R.id.viewTxtHello);

        btnSayHello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTxtHello.setText("Hello");
                viewTxtHello.setText("Hello");
            }
        });
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.i(LC, "This triggered onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(LC, "This triggered onStop");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(LC, "This triggered onStart");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(LC, "This triggered onRestart");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.i(LC, "This triggered onDestroy");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.i(LC, "This triggered onResume");

    }

    

}