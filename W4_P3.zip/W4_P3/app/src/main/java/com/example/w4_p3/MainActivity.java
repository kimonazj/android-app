package com.example.w4_p3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    //string list of words and the two hints
    public static final String[] WORDS = {
            "MILK,food,white", "BLUE,color,sky", "YEAR,time,calendar", "CLOCK,time,object", "FLOWER,colorful,plant"
    };

    //string list of consonants and vowels
    public static final ArrayList<String> CONSONANT = new ArrayList<String>(
            Arrays.asList("B","C","D","F","G","H","J","K","L","M","N","P","Q","R","S","T","V","W","X","Y","Z"));
    public static final ArrayList<String> VOWEL = new ArrayList<String>(
            Arrays.asList("A","E","I","O","U","Y"));

    //use random to choose a word in the words_array
    public static final Random RANDOM = new Random();

    //set the max errors to 6
    public static final int MAX_ERRORS = 6;

    //set up goal and hint variables
    private String wordToFind;
    private String hint1;
    private String hint2;

    //set up variables for user progression
    private char[] wordFound;
    private int errorNum;
    private int hintCount;
    private int score;

    //buttons and a button list
    private Button A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Rbtn,S,T,U,V,W,X,Y,Z;
    private List<Button> keyboards;

    // android view variables
    private Button restartBtn;
    private ImageView img;
    private TextView wordTv;
    private TextView wordToFindTv;
    private Button hintBtn;
    private TextView hintTv;

    //choose the word randomly
    //return a string list with element (0: the word) (1: hint1) (2: hint2)
    private String[] nextWordAndHints() {
        String[] wordsAndHints = WORDS[RANDOM.nextInt(WORDS.length)].split(",");
        return wordsAndHints;
    }

    // update the image according to the error number
    private void updateImg(int error) {
        int resImg = getResources().getIdentifier("hangman_" + error, "drawable", getPackageName());
        img.setImageResource(resImg);
    }

    //a method to add space to the wordFound string, used in wordFoundTv.setText()
    //the goal is to show the length of the word
    private String wordFoundContent() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < wordFound.length; i++) {
            builder.append(wordFound[i]);
            if (i < wordFound.length - 1) {
                builder.append(" ");
            }
        }
        return builder.toString();
    }

    //check the score (if consonant += 5, vowel += 10)
    private int updateScore(String c){
        if(CONSONANT.contains(c)){
            return 5;
        }
        else if(VOWEL.contains(c)){
            return 10;
        }
        else{
            return 0;
        }
    }

    //a method to enable all letter btns
    public void enableBtns(){
        for(Button btn: keyboards){
            btn.setEnabled(true);
        }
    }

    // Method for starting a new game
    public void newGame() {
        errorNum = 0;
        hintCount = 0;
        String[] wordAndHints = nextWordAndHints();
        wordToFind = wordAndHints[0];
        hint1 = wordAndHints[1];
        hint2 = wordAndHints[2];

        //initialize the wordFound to empty
        wordFound = new char[wordToFind.length()];

        //replace '_' to empty place
        for (int i = 0; i < wordFound.length; i++) {
            wordFound[i] = '_';
        }

        //update the image
        updateImg(errorNum);
        wordTv.setText(wordFoundContent());
        wordToFindTv.setText("");
        enableBtns();

        hintBtn.setEnabled(true);
        hintTv.setText("");
        score = 0;
    }

    // update current display on the string under the hang man
    private void enter(String c) {
        // check if word to find contains c
        if (wordToFind.contains(c)) {
            // if so, replace _ by the character c
            int index = wordToFind.indexOf(c);

            while (index >= 0) {
                wordFound[index] = c.charAt(0);
                index = wordToFind.indexOf(c, index + 1);
            }
            score += updateScore(c);
        } else {
            //c not in the word => error
            errorNum++;
            Toast.makeText(this, R.string.try_another, Toast.LENGTH_SHORT).show();
        }
    }

    public boolean wordFound() {
        return wordToFind.contentEquals(new String(wordFound));
    }

    public void touchLetter(View v) {
        if (errorNum < MAX_ERRORS && !getString(R.string.you_win).equals(wordToFindTv.getText())) {
            //find the letter and change the button to disable
            String letter = ((Button) v).getText().toString();
            v.setEnabled(false);

            //update
            enter(letter);
            wordTv.setText(wordFoundContent());
            updateImg(errorNum);

            //check if word is found
            if (wordFound()) {
                //if the word is found, the toast will display the score and the wordTOFindTV will say "you win" message
                Toast.makeText(this, "Your score is:"+score, Toast.LENGTH_LONG).show();
                wordToFindTv.setText(R.string.you_win);
            } else {
                if (errorNum >= MAX_ERRORS) {
                    //if the word isn't found but reach the maxerror
                    //the toast will display the score and the wordToFindTv View will tell you what the word was
                    Toast.makeText(this, "Your score is:"+score, Toast.LENGTH_LONG).show();
                    wordToFindTv.setText(getString(R.string.word_to_find).replace("#word#", wordToFind));
                }
            }
        } else {
            //if you accidently press a button after the game ends, the toast will remind you to start a new game
            Toast.makeText(this, R.string.game_has_ended, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialization
        restartBtn = (Button)findViewById(R.id.resetbtn);
        hintBtn = (Button)findViewById(R.id.hintbtn);


        img = findViewById(R.id.img);
        wordTv = findViewById(R.id.wordTv);
        wordToFindTv = findViewById(R.id.wordToFindTv);
        hintTv = findViewById(R.id.hintword);

        // initialize the keyboard list
        keyboards= new ArrayList<Button>();
        A = findViewById(R.id.abtn); keyboards.add(A);
        B = findViewById(R.id.bbtn); keyboards.add(B);
        C = findViewById(R.id.cbtn); keyboards.add(C);
        D = findViewById(R.id.dbtn); keyboards.add(D);
        E = findViewById(R.id.ebtn); keyboards.add(E);
        F = findViewById(R.id.fbtn); keyboards.add(F);
        G = findViewById(R.id.gbtn); keyboards.add(G);
        H = findViewById(R.id.hbtn); keyboards.add(H);
        I = findViewById(R.id.ibtn); keyboards.add(I);
        J = findViewById(R.id.jbtn); keyboards.add(J);
        K = findViewById(R.id.kbtn); keyboards.add(K);
        L = findViewById(R.id.lbtn); keyboards.add(L);
        M = findViewById(R.id.mbtn); keyboards.add(M);
        N = findViewById(R.id.nbtn); keyboards.add(N);
        O = findViewById(R.id.obtn); keyboards.add(O);
        P = findViewById(R.id.pbtn); keyboards.add(P);
        Q = findViewById(R.id.qbtn); keyboards.add(Q);
        Rbtn = findViewById(R.id.rbtn); keyboards.add(Rbtn);
        S = findViewById(R.id.sbtn); keyboards.add(S);
        T = findViewById(R.id.tbtn); keyboards.add(T);
        U = findViewById(R.id.ubtn); keyboards.add(U);
        V = findViewById(R.id.vbtn); keyboards.add(V);
        W = findViewById(R.id.wbtn); keyboards.add(W);
        X = findViewById(R.id.xbtn); keyboards.add(X);
        Y = findViewById(R.id.ybtn); keyboards.add(Y);
        Z = findViewById(R.id.zbtn); keyboards.add(Z);

        if (savedInstanceState == null) {
            newGame();
        }

        restartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newGame();
            }
        });

        //if in landscape, we can use hintbtn
        int orientation = getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // In landscape
            hintBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (hintCount == 0 && errorNum<MAX_ERRORS){
                        hintTv.setText(hint1);
                        hintCount++;
                        errorNum++;
                        updateImg(errorNum);

                        if (errorNum >= MAX_ERRORS) {
                            Toast.makeText(getApplicationContext(),"you lose",Toast.LENGTH_LONG).show();
                            wordToFindTv.setText(getString(R.string.word_to_find).replace("#word#", wordToFind));
                        }
                    }
                    else if(hintCount==1 && errorNum < MAX_ERRORS){
                        hintTv.setText(hint2);
                        hintCount++;
                        errorNum++;
                        updateImg(errorNum);

                        if (errorNum >= MAX_ERRORS) {
                            Toast.makeText(getApplicationContext(),"you lose",Toast.LENGTH_LONG).show();
                            wordToFindTv.setText(getString(R.string.word_to_find).replace("#word#", wordToFind));
                        }
                    }

                    //when hintcount is 2, it will fill one letter
                    else if(hintCount==2 && errorNum < MAX_ERRORS){
                        //fill one letter
                        int index = 0;
                        for(int i = 0; i<wordFound.length;i++){
                            if(wordFound[i]=='_'){
                                index = i;
                            }
                        }
                        char ch = wordToFind.charAt(index);
                        for(int i = 0; i<wordToFind.length();i++){
                            if(wordToFind.charAt(i)==ch){
                                wordFound[i] = ch;
                            }
                        }

                        wordTv.setText(wordFoundContent());
                        hintBtn.setEnabled(false);

                        //disable the hint button
                        for(Button btn : keyboards){
                            if(btn.getText().toString().equals(String.valueOf(ch))){
                                btn.setEnabled(false);
                                break;
                            }
                        }

                        errorNum++;
                        updateImg(errorNum);
                        //check if lose
                        if (wordFound()) {
                            //when win
                            Toast.makeText(getApplicationContext(),"your score is:"+score,Toast.LENGTH_LONG).show();
                            wordToFindTv.setText(R.string.you_win);
                        } else {
                            //when errornum is more than max
                            if (errorNum >= MAX_ERRORS) {
                                Toast.makeText(getApplicationContext(),"you lose",Toast.LENGTH_LONG).show();
                                wordToFindTv.setText(getString(R.string.word_to_find).replace("#word#", wordToFind));
                            }
                        }
                    }
                }
            });
        } else {
//            Toast.makeText(this, R.string.game_has_ended, Toast.LENGTH_SHORT).show();
            hintBtn.setVisibility(View.GONE);
        }

    }

    //save state
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState (savedInstanceState);

        boolean[] keyboardsEnabled = savedInstanceState.getBooleanArray("keyboardsEnabled");
        for (int idx = 0; idx < keyboardsEnabled.length; idx ++) {
            boolean btnEnable = keyboardsEnabled[idx];
            keyboards.get(idx).setEnabled(btnEnable);
        }

        hintCount = savedInstanceState.getInt("hintCount");
        hintBtn.setEnabled(savedInstanceState.getBoolean("hintBtn"));
        hintTv.setText(savedInstanceState.getString("hintTv"));

        errorNum = savedInstanceState.getInt("errorNum");
        wordToFind = savedInstanceState.getString("wordToFind");
        hint1 = savedInstanceState.getString("hint1");
        hint2 = savedInstanceState.getString("hint2");
        wordToFindTv.setText(savedInstanceState.getString("wordToFindTv"));
        wordTv.setText(savedInstanceState.getString("wordTv"));
        updateImg(errorNum);
        score = savedInstanceState.getInt("score");
        wordFound = savedInstanceState.getCharArray("wordFound");
    }

    protected void onSaveInstanceState (Bundle savedInstanceState) {
        super.onSaveInstanceState (savedInstanceState);

        // Find the current enabled state of each letter on the keyboard
        boolean keyboardsEnabled[] = new boolean[keyboards.size()];
        for (int idx = 0; idx < keyboards.size(); idx ++) {
            keyboardsEnabled[idx] = keyboards.get(idx).isEnabled();
        }

        // save the array into our bundle
        savedInstanceState.putBooleanArray("keyboardsEnabled", keyboardsEnabled);

        // save relevant data for the hint Button
        savedInstanceState.putInt("hintCount", hintCount);
        savedInstanceState.putBoolean("hintBtn", hintBtn.isEnabled());
        savedInstanceState.putString("hintTv", hintTv.getText().toString());

        // save relevant data for errorNum and answer displays
        savedInstanceState.putInt("errorNum", errorNum);
        savedInstanceState.putString("wordToFind", wordToFind);
        savedInstanceState.putString("hint1", hint1);
        savedInstanceState.putString("hint2", hint2);
        savedInstanceState.putString("wordToFindTv", wordToFindTv.getText().toString());
        savedInstanceState.putString("wordTv", wordTv.getText().toString());
        savedInstanceState.putCharArray("wordFound", wordFound);
        savedInstanceState.putInt("score", score);

    }
}