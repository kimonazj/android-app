package com.example.w8_p1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PreferencesActivity extends AppCompatActivity {
    private Button save;
    private Button clear;
    private EditText phoneContact;
    private EditText textContact;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferences);

        // Finding view objects
        save = (Button) findViewById(R.id.btnSave);
        clear = (Button) findViewById(R.id.btnClear);
        phoneContact = (EditText) findViewById(R.id.edtPhoneContact);
        textContact = (EditText) findViewById(R.id.edtTextContact);

        // Set contact fields to values if they already exist
        SharedPreferences prefs = getSharedPreferences("EmergencyPreferences", Context.MODE_PRIVATE);
        phoneContact.setText(prefs.getString("PhoneContact", ""));
        textContact.setText(prefs.getString("TextContact", ""));
        final SharedPreferences.Editor editor = prefs.edit();

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(phoneContact.getText().toString().isEmpty() && textContact.getText().toString().isEmpty())) {
                    editor.putString("PhoneContact", phoneContact.getText().toString());
                    editor.putString("TextContact", textContact.getText().toString());
                    editor.apply();
                    Toast.makeText(getBaseContext(), "Saved", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getBaseContext(), "Please type at least one contact before saving", Toast.LENGTH_SHORT).show();
                }

            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.clear().apply();
                phoneContact.setText("");
                textContact.setText("");
            }
        });

    }
}
