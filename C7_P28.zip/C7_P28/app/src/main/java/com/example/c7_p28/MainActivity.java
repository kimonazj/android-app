package com.example.c7_p28;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener{

    private TextView tv;
    private GestureDetector GD;    //must instantiate the gesture detector

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = (TextView)findViewById(R.id.tv);
        GD = new GestureDetector(this, this);   //Context, Listener as per Constructor Doc.
        GD.setOnDoubleTapListener(this);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.GD.onTouchEvent(event);

        if(!(event.getAction() == MotionEvent.ACTION_UP)) {
            tv.setX(event.getX());
            tv.setY(event.getY());
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        Log.i("velocityX", Float.toString(velocityX));
        Log.i("velocityY", Float.toString(velocityY));

        Point size = new Point();
        Display display = getWindowManager().getDefaultDisplay();
        display.getSize(size);
        int width = size.x;
        int height = size.y;

        Log.i("width", Integer.toString(width));
        Log.i("height", Integer.toString(height));

        if (Math.abs(velocityX) > 20000 || Math.abs(velocityY) > 20000) {
            float x_coor = (float) Math.random() * width * 9 / 10;
            float y_coor = (float) Math.random() * height * 9 / 10;

            Toast.makeText(getApplicationContext(),"You moved too fast, the message will reappear at a random point!", Toast.LENGTH_SHORT).show();
            tv.setX(x_coor);
            tv.setY(y_coor);
        }

        return true;
    }

}