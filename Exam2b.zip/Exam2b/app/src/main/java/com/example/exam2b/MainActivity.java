package com.example.exam2b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.text.TextUtils;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    // All the resources as required
    Button btnLogin;
    EditText edtUserName;

    // A string to store the user's name
    String Username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize the ui
        btnLogin = (Button)findViewById(R.id.btnLogin);
        edtUserName = (EditText)findViewById(R.id.edtUserName);

        // when the login button is clicked
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // if the username is empty, just render a toast
                if(TextUtils.isEmpty(edtUserName.getText().toString())){
                    Toast.makeText(getBaseContext(),"Please Try Again", Toast.LENGTH_SHORT).show();
                }else{
                    // if the username is not empty, start the second activity and pass the username
                    Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                    Username = edtUserName.getText().toString();
                    intent.putExtra("username",Username);
                    startActivity(intent);

                }
            }
        });
    }
}