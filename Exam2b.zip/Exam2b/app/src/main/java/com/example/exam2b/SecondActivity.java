package com.example.exam2b;

import android.content.Context;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Array;
import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {

    // list view and list adapter
    ListView lvE;
    ListAdapter lvA;

    // username from activity one
    String username;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // greeting the user
        username = getIntent().getStringExtra("username");
        Toast.makeText(getBaseContext(),"Hello "+username,Toast.LENGTH_SHORT).show();

        // initialization
        lvE = (ListView)findViewById(R.id.listview);
        lvA = new MyCustomAdapter(this.getBaseContext());
        lvE.setAdapter(lvA);
    }
}

// have a class for customadapter
class MyCustomAdapter extends BaseAdapter{

    // arraylist of animal images and string array of animal names
    ArrayList<Integer> animalImages;
    String animalNames[];

    Context context;

    public MyCustomAdapter(Context acontext){
        // initialization
        context = acontext;
        animalNames = acontext.getResources().getStringArray(R.array.animals);

        animalImages = new ArrayList<Integer>();
        animalImages.add(R.drawable.p1);
        animalImages.add(R.drawable.p2);
        animalImages.add(R.drawable.p3);
    }
    @Override
    public int getCount() {
        return animalNames.length;
    }

    @Override
    public Object getItem(int position) {
        return animalNames[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View row;

        // if the view is null, inflate it; if it's already there, just let row be the convertView
        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.listview_row, parent, false);
        }else{
            row = convertView;
        }

        // find resources in view row
        ImageView animalIMG = (ImageView)row.findViewById(R.id.animalIMG);
        TextView animalTV = (TextView)row.findViewById(R.id.animalTV);

        // set up one row
        animalIMG.setImageResource(animalImages.get(position).intValue());
        animalTV.setText(animalNames[position]);

        // return the customized view
        return row;
    }
}
