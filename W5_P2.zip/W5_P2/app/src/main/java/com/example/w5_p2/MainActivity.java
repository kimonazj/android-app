package com.example.w5_p2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.VelocityTracker;
import android.widget.EditText;
import android.widget.TextView;

///////  Set of imports for Gesture Detection ////////
import android.view.MotionEvent;
import android.view.GestureDetector;
import android.widget.Toast;

public class MainActivity extends Activity
        implements GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener {

    // All the Views for manipulation
    private EditText input;
    private TextView rupis;
    private TextView yen;
    private TextView yuan;
    private TextView pounds;
    private GestureDetector GD;

    // VelocityTracker and related variables for scroll events
    VelocityTracker velocityTracker;
    double y_velocity;

    // variables used to calculate and compare velocity.
    // VELOCITY_THRESHOLD determines if a motion is a scroll or a fling.
    int MAX_VELOCITY = 1000;
    double VELOCITY_THRESHOLD = 2500;

    // Helper function to round money down to the cents.
    public double roundMoney(double money) {
        double roundedValue = (double) Math.round(money * 100) / 100.0;
        return roundedValue;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GD = new GestureDetector(this, this);

        input = (EditText)findViewById(R.id.input);
        rupis = (TextView)findViewById(R.id.rupis);
        yen  = (TextView)findViewById(R.id.yen);
        yuan = (TextView)findViewById(R.id.yuan);
        pounds = (TextView)findViewById(R.id.pounds);

        input.setText("0.00");

        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                double input_dollar;
                    try {
                        input_dollar = Double.parseDouble(s.toString());
                        if(input_dollar < 0){
                            Toast.makeText(getApplicationContext(),"It's lower than 0, set to 0 by default",Toast.LENGTH_SHORT).show();
                            input.setText("0.00");
                            input_dollar = 0;
                        }
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(),"Invalid input, set to 0 by default",Toast.LENGTH_SHORT).show();
                        input_dollar = 0;
                    }

                // calculate the appropriate currencies
                double r = input_dollar*73.18;
                double ye = input_dollar*108.4;
                double yu = input_dollar*6.5;
                double p = input_dollar*0.72;

                // set texts to their corresponding currencies, rounded down to cents (i.e. 2 decimal places)
                rupis.setText(Double.toString(roundMoney(r)));
                yen.setText(Double.toString(roundMoney(ye)));
                yuan.setText(Double.toString(roundMoney(yu)));
                pounds.setText(Double.toString(roundMoney(p)));
            }
        });

    }

    //////////////////////////////////////////////////////////////////////////
    //very important step, otherwise we won't be able to capture our touches//
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.GD.onTouchEvent(event);               //Our GD will not automatically receive Android Framework Touch notifications.
        // Insert this line to consume the touch event locally by our GD,
        // IF YOU DON'T insert this before the return, our GD will not receive the event, and therefore won't do anything.
        return super.onTouchEvent(event);          // Do this last, why?
    }
    //////////////////////////////////////////////////////////////////////////

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        velocityTracker = VelocityTracker.obtain();
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {

        // Track the current velocity of our finger movement
        velocityTracker.addMovement(e2);
        velocityTracker.computeCurrentVelocity(MAX_VELOCITY);
        y_velocity = velocityTracker.getYVelocity();

        // If the velocity of the finger movement is too fast
        // then it is a fling, and not a scroll.
        if (Math.abs(y_velocity) >= VELOCITY_THRESHOLD) {
            return false;
        }

        // if it is not a fling, execute the changes in onScroll
        double input_dollar;
        try {
            input_dollar = Double.parseDouble(input.getText().toString());
            if(input_dollar < 0){
                Toast.makeText(getApplicationContext(),"It's lower than 0, set to 0 by default",Toast.LENGTH_SHORT).show();
                input_dollar = 0;
            }
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Invalid input, set to 0 by default",Toast.LENGTH_SHORT).show();
            input_dollar = 0;
        }

        if(distanceY > 0){
            input_dollar += 0.05;
            input.setText(Double.toString(roundMoney(input_dollar)));
        }
        else {
            input_dollar -= 0.05;
            input.setText(Double.toString(roundMoney(input_dollar)));
        }
        return true;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {

        // If the finger movement is too slow, then it is not a fling,
        // return false.
        if (Math.abs(velocityY) < VELOCITY_THRESHOLD) {
            return false;
        }

        // otherwise, execute normal fling commands
        double input_dollar;
        try {
            input_dollar = Double.parseDouble(input.getText().toString());
            if(input_dollar < 0){
                Toast.makeText(getApplicationContext(),"It's lower than 0, set to 0 by default",Toast.LENGTH_SHORT).show();
                input_dollar = 0;
            }
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Invalid input, set to 0 by default",Toast.LENGTH_SHORT).show();
            input_dollar = 0;
        }

        float diffY = e2.getY() - e1.getY();
        if(diffY < 0){
            input_dollar += 1;
            input.setText(Double.toString(input_dollar));
        }
        else{
            input_dollar -= 1;
            input.setText(Double.toString(input_dollar));
        }
        return true;
    }
}