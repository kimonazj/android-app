package com.example.w3_p3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ThreadLocalRandom;

public class HomePage extends MainActivity {

    Button start;
    TextView num1;
    TextView num2;
    EditText answer;
    Button submit;
    TextView correct;
    Button restart;

    int correct_num;
    int counter;
    int denominator;
    int nominator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);

        start = (Button)findViewById(R.id.start);
        num1 = (TextView)findViewById(R.id.num1);
        num2 = (TextView)findViewById(R.id.num2);
        answer = (EditText)findViewById(R.id.answer);
        submit = (Button)findViewById(R.id.submit);
        correct = (TextView)findViewById(R.id.correct);
        restart = (Button)findViewById(R.id.restart);

        submit.setEnabled(false);
        restart.setEnabled(false);

        counter = 0;
        correct_num = 0;


        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                denominator = ThreadLocalRandom.current().nextInt(1, 13);
                nominator = denominator * ThreadLocalRandom.current().nextInt(1, 13);
                num2.setText(String.valueOf(denominator));
                num1.setText(String.valueOf(nominator));
                correct.setText(String.format("%d/%d", correct_num, counter));

                start.setEnabled(false);
                submit.setEnabled(true);
                restart.setEnabled(true);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answer.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(),"Please enter an answer.",Toast.LENGTH_SHORT).show();
                } else {
                    if (Integer.parseInt(answer.getText().toString()) == (nominator / denominator)) {
                        correct_num += 1;
                    }

                    denominator = ThreadLocalRandom.current().nextInt(1, 13);
                    nominator = denominator * ThreadLocalRandom.current().nextInt(1, 13);
                    num2.setText(String.valueOf(denominator));
                    num1.setText(String.valueOf(nominator));

                    counter += 1;
                    correct.setText(String.format("%d/%d", correct_num, counter));

                    if (counter == 10) {
                        Toast.makeText(getApplicationContext(),"You scored " + String.format("%d/%d", correct_num, counter),Toast.LENGTH_SHORT).show();
                        submit.setEnabled(false);
                    }
                }

            }
        });

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                correct_num = 0;
                counter = 0;

                denominator = ThreadLocalRandom.current().nextInt(1, 13);
                nominator = denominator * ThreadLocalRandom.current().nextInt(1, 13);
                num2.setText(String.valueOf(denominator));
                num1.setText(String.valueOf(nominator));
                correct.setText(String.format("%d/%d", correct_num, counter));

                submit.setEnabled(true);
                Toast.makeText(getApplicationContext(),"Game score has been reset.",Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("num1", num1.getText().toString());
        savedInstanceState.putString("num2", num2.getText().toString());
        savedInstanceState.putString("correct", correct.getText().toString());
        savedInstanceState.putString("answer", answer.getText().toString());

        savedInstanceState.putInt("counter", counter);
        savedInstanceState.putInt("correct_num", correct_num);

        savedInstanceState.putBoolean("start_enabled", start.isEnabled());
        savedInstanceState.putBoolean("submit_enabled", submit.isEnabled());
        savedInstanceState.putBoolean("restart_enabled", restart.isEnabled());

    };

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        num1.setText(savedInstanceState.getString("num1"));
        num2.setText(savedInstanceState.getString("num2"));
        correct.setText(savedInstanceState.getString("correct"));
        answer.setText(savedInstanceState.getString("answer"));
        counter = savedInstanceState.getInt("counter");
        correct_num = savedInstanceState.getInt("correct_num");

        nominator = Integer.parseInt(num1.getText().toString());
        denominator = Integer.parseInt(num2.getText().toString());

        start.setEnabled(savedInstanceState.getBoolean("start_enabled"));
        submit.setEnabled(savedInstanceState.getBoolean("submit_enabled"));
        restart.setEnabled(savedInstanceState.getBoolean("restart_enabled"));
    }


}
