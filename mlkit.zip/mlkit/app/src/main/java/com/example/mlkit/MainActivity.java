package com.example.mlkit;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements Frag.FragListener {

    EditText sharePtv;
    Button retrievebtn;
    Button savebtn;

    ListView lvE;
    ListAdapter lvA;

    Button showmap;
    Button callnum;
    Button sendsms;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharePtv = (EditText)findViewById(R.id.sharePtv);
        retrievebtn = (Button)findViewById(R.id.retrieveP);
        savebtn = (Button)findViewById(R.id.saveP);

        lvE = (ListView)findViewById(R.id.listview);
        lvA = new MyCustonAdapter(this.getBaseContext());
        lvE.setAdapter(lvA);

        showmap = (Button)findViewById(R.id.showmap);
        callnum = (Button)findViewById(R.id.callnum);
        sendsms = (Button)findViewById(R.id.sms);
        //for sharedpreferences
        retrievebtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveSharedPreferenceInfo();
            }
        }));

        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSharedPreferenceInfo();
            }
        });
        showmap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent geolocationIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+"coco park"));
                    startActivity(geolocationIntent);
                }catch(Exception e){
                    Toast.makeText(getBaseContext(), "showmap wrong", Toast.LENGTH_LONG).show();
                }
            }
        });
        callnum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent phonecall = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+"13798"));
                startActivity(phonecall);
            }
        });
        sendsms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setupPendingIntent();

            }
        });
    }

    protected void setupPendingIntent() {
        Intent sendIntent = new Intent(Intent.ACTION_VIEW);
        sendIntent.putExtra("address","135466");
        sendIntent.putExtra("sms_body","hi there");
        sendIntent.setType("vnd.android-dir/mms-sms");

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 9999,sendIntent,PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);  //just another manager, this one sets an alarm.
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + (3*1000), pendingIntent);  //When the alarm manager runs it will be running as the user who initiated it.
    }
    void saveSharedPreferenceInfo(){
        SharedPreferences preInfo = getSharedPreferences("ActivityOneInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preInfo.edit();
        editor.putString("sharePtv", sharePtv.getText().toString());
        editor.apply();

    }

    void retrieveSharedPreferenceInfo(){
        SharedPreferences preInfo = getSharedPreferences("ActivityOneInfo", Context.MODE_PRIVATE);
        sharePtv.setText(preInfo.getString("sharePtv", "<missing>"));
    }

    // for interFragment communication
    public void sendMessage(String message){
        DisplayFrag dfrag = (DisplayFrag)getFragmentManager().findFragmentById(R.id.frag2);
        dfrag.display(message);
    }

    //for menu
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.simple_menu,menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if(id == R.id.it1){
            Toast.makeText(getBaseContext(), "it1 selected.", Toast.LENGTH_LONG).show();
            return true;
        }
        if(id==R.id.it2){
            Toast.makeText(getBaseContext(), "it2 selected", Toast.LENGTH_LONG).show();
            return true;
        }else{
            return super.onOptionsItemSelected(item);
        }
    }
}

class MyCustonAdapter extends BaseAdapter{

    String[] messages;
    String[] btnmessages;

    Button messagebtn;
    TextView messagetv;

    Context context;

    public MyCustonAdapter(Context baseContext) {
        context = baseContext;
        messages = baseContext.getResources().getStringArray(R.array.funny_message);
        btnmessages = baseContext.getResources().getStringArray(R.array.btn_message);
    }

    @Override
    public int getCount() {
        return messages.length;
    }

    @Override
    public Object getItem(int position) {
        return messages[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row;
        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.listviewrow,parent,false);
        }else{
            row  = convertView;
        }

        messagebtn = (Button)row.findViewById(R.id.messagebtn);
        messagetv = (TextView)row.findViewById(R.id.messagetv);
        messagebtn.setText(btnmessages[position]);
        messagetv.setText(messages[position]);
        messagebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, btnmessages[position], Toast.LENGTH_LONG).show();
            }
        });
        return row;
    }
}