package com.example.mlkit;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import android.app.Fragment;

public class Frag extends Fragment {

    Button sendbtn;
    EditText edttext;

    public Frag(){

    }

    // for interFragment communication
    public interface FragListener{
        public void sendMessage(String message);
    }

    FragListener CFL;

   // public void onAttach(Context context) {
     //   super.onAttach(context);
   //     CFL = (FragListener) context;
   // }

   // for interFragment communication
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        CFL = (FragListener) activity;
    }


    // for interFragment communication
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view=inflater.inflate(R.layout.fragment1,container,false);
        sendbtn = (Button)view.findViewById(R.id.sendbtn);
        edttext = (EditText)view.findViewById(R.id.edttext);
        sendbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CFL.sendMessage(edttext.getText().toString());
            }
        });
        return view;
    }
}
